export interface Food {
    id: number;
    name: string;
}
