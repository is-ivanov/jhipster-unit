INSERT INTO company VALUES (1, 'google', 'corporation google', 'google@gmail.com');

INSERT INTO app_user VALUES (1, 1);
